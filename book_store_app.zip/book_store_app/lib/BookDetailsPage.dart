import 'package:flutter/material.dart';
class BookDetailsPage extends StatelessWidget {
  final Map<String, String> book;

  BookDetailsPage({required this.book});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Center(
            // Center the title
            child: Text(
              book['title']!,
              style:
              TextStyle(fontWeight: FontWeight.bold), // Make the title bold
            ),
          ),
          backgroundColor: Colors.blue,
          centerTitle: true,
        ),
        body: Container(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.network(book['imageUrl']!,
                    height: 200, width: double.infinity),
                SizedBox(height: 16),
                Text(
                  book['title']!,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  "Author: ${book['author']}",
                  style: TextStyle(fontSize: 18),
                ),
                SizedBox(height: 8),
                Text(
                  "Price: ${book['price']}",
                  style: TextStyle(fontSize: 18),
                ),
                SizedBox(height: 16),
                Text(
                  "Description: This is a placeholder for the book description.",
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 16),
                Text(
                  "Reviews: Placeholder for user reviews.",
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            ),
        );
    }
}